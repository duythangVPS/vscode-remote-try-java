module.exports = {
	secret: "mWViBiW3CGRGFhoj3WjrelH26Iiz8zIj"
}